from litellm import acompletion

from .config import get_settings


async def ask_local_model(prompt: str) -> str:
    settings = get_settings()
    response = await acompletion(
        model=f"ollama/{settings.local_model}",
        api_base=settings.ollama_base_url,
        messages=[{"role": "user", "content": prompt}],
    )
    content = response.choices[0].message.content
    return content if isinstance(content, str) else ""
