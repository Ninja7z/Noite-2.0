# Pacote de revisão — Noite 2.0

Snapshot dos arquivos locais do MVP para revisão do Claude.

## Conteúdo
- `README.md`, `pyproject.toml`, `.env.example`, `SECURITY.md`, `.gitignore`
- `docs/roadmap.md`
- `src/noite/*.py`
- `ruff-check.txt` com a saída executada em 2026-10-31

## Limites desta revisão
- A pasta local não contém `.git`; não há `git diff`, histórico nem remoto para gerar o diff do PR.
- A integração GitHub conectada ao Codex não consegue acessar `Ninja7z/Noite-2.0` nem localizar o repo sob `cristnzx`; PR #1 não acessível por esta conexão.
- Não foi encontrado diretório de testes no snapshot. Nenhum teste foi executado.
- `.env` (configuração local) foi deliberadamente excluído. O pacote inclui apenas `.env.example`, sem valores secretos.

## Lint
`ruff check .` foi executado no ambiente virtual do projeto. A saída completa está em `ruff-check.txt`.
